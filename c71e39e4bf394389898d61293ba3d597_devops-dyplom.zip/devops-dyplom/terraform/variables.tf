variable "region" {
  type    = string
  default = "eu-central-1"
}
variable "project" {
  type    = string
  default = "devops-diploma"
}
variable "instance_type" {
  type    = string
  default = "t3.micro"
}
variable "ssh_public_key" {
  type        = string
  description = "Zawartość pliku ~/.ssh/id_ed25519.pub"
}
variable "ssh_allowed_cidr" {
  type        = string
  default     = "0.0.0.0/0"
  description = "Zawęź do swojego IP (x.x.x.x/32) dla bezpieczeństwa"
}
