terraform {
  required_version = ">= 1.5"
  required_providers {
    aws = { source = "hashicorp/aws", version = "~> 5.0" }
  }
}

provider "aws" {
  region = var.region
}

# Aktualny obraz Amazon Linux 2023 - pobierany dynamicznie, nie na sztywno.
data "aws_ssm_parameter" "al2023" {
  name = "/aws/service/ami-amazon-linux-latest/al2023-ami-kernel-default-x86_64"
}

# Klucz SSH - publiczna część podawana jako zmienna, prywatna zostaje u Ciebie.
resource "aws_key_pair" "deploy" {
  key_name   = "${var.project}-key"
  public_key = var.ssh_public_key
}

resource "aws_security_group" "app" {
  name        = "${var.project}-sg"
  description = "SSH, HTTP, Grafana"

  dynamic "ingress" {
    for_each = { ssh = 22, http = 80, grafana = 3000 }
    content {
      description = ingress.key
      from_port   = ingress.value
      to_port     = ingress.value
      protocol    = "tcp"
      cidr_blocks = ingress.key == "ssh" ? [var.ssh_allowed_cidr] : ["0.0.0.0/0"]
    }
  }
  egress {
    from_port   = 0
    to_port     = 0
    protocol    = "-1"
    cidr_blocks = ["0.0.0.0/0"]
  }
}

resource "aws_instance" "app" {
  ami                    = data.aws_ssm_parameter.al2023.value
  instance_type          = var.instance_type
  key_name               = aws_key_pair.deploy.key_name
  vpc_security_group_ids = [aws_security_group.app.id]

  # Instalacja Dockera i pluginu compose przy pierwszym starcie.
  user_data = <<-EOT
    #!/bin/bash
    dnf install -y docker
    systemctl enable --now docker
    usermod -aG docker ec2-user
    mkdir -p /usr/local/lib/docker/cli-plugins
    curl -SL https://github.com/docker/compose/releases/download/v2.29.7/docker-compose-linux-x86_64 \
      -o /usr/local/lib/docker/cli-plugins/docker-compose
    chmod +x /usr/local/lib/docker/cli-plugins/docker-compose
  EOT

  tags = { Name = var.project }
}

# Stały adres IP - żeby pipeline zawsze wiedział, dokąd się łączyć.
resource "aws_eip" "app" {
  instance = aws_instance.app.id
  domain   = "vpc"
}
