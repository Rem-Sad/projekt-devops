## Intro
Projekt to prosta aplikacja FastAPI w kontenerze. Skupiłem się na tym, co otacza aplikację:
Terraform tworzy serwer na AWS, GitHub Actions buduje i wdraża, Prometheus/Grafana monitorują,
Discord dostaje powiadomienia. Cel: od commita do produkcji bez ręcznych kroków.

## Scenariusze wykonanych testów
1. Pokaż `terraform apply` (lub już postawioną infrastrukturę + `terraform plan` = "No changes" -> idempotentność).
2. Zmień tekst w `app/main.py` na branchu `feature/x`, push -> w Actions leci build + push obrazu, BRAK deployu, jest powiadomienie.
3. Merge do `main` -> build + deploy + powiadomienie na Discord.
4. Odśwież `http://IP/` - nowa wersja. Pokaż Docker Hub z nowym tagiem sha.
5. Monitoring: Grafana + `docker stop` aplikacji na serwerze -> po ~1 min alert `AppDown` na Discordzie.

