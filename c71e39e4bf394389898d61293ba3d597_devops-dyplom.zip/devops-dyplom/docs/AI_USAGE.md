# Wykorzystanie AI w projekcie
Szkielet projektu (kod, Dockerfile, Terraform, pipeline, konfiguracja monitoringu) wygenerowano
z pomocą Claude (Anthropic). Samodzielnie skonfigurowałem konto AWS, Docker Hub, webhook Discord, sekrety, uruchomił i przetestował wdrożenie, zweryfikował alerty,
poprawiłem błędy jakie popełniło AI. Każdy element został przejrzany i zweryfikowany przez autora.
