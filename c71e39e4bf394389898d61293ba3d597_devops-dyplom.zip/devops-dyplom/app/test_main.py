from fastapi.testclient import TestClient
from main import app

client = TestClient(app)


def test_healthcheck():
    assert client.get("/healthcheck").json() == {"status": "ok"}


def test_create_and_list_task():
    r = client.post("/tasks", json={"title": "test"})
    assert r.status_code == 201
    assert any(t["title"] == "test" for t in client.get("/tasks").json())


def test_empty_title_rejected():
    assert client.post("/tasks", json={"title": "  "}).status_code == 422


def test_metrics_exposed():
    assert "tasks_created_total" in client.get("/metrics").text
