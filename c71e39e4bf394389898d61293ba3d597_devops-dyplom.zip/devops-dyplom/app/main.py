"""Prosta aplikacja FastAPI (lista zadań) z endpointem /metrics dla Prometheusa.
Dlaczego tak prosta: w dobrym projekcie DevOps liczy się to, co dzieje się WOKÓŁ aplikacji
(build, publikacja, wdrożenie, monitoring), a nie jej logika."""
from fastapi import FastAPI, HTTPException, Response
from pydantic import BaseModel
from prometheus_client import Counter, generate_latest, CONTENT_TYPE_LATEST

app = FastAPI(title="DevOps Diploma App")

# Metryka biznesowa - pokazuje, że monitorujemy nie tylko CPU, ale i aplikację.
TASKS_CREATED = Counter("tasks_created_total", "Liczba utworzonych zadań")
REQUESTS = Counter("app_requests_total", "Liczba żądań", ["endpoint"])

tasks: list[dict] = []  # magazyn w pamięci (wystarczy na potrzeby projektu)


class TaskIn(BaseModel):
    title: str


@app.get("/")
def root():
    REQUESTS.labels("/").inc()
    return {"message": "Hello from DevOps diploma project"}


@app.get("/healthcheck")
def healthcheck():
    # Używany przez Docker HEALTHCHECK i load balancer/monitoring.
    return {"status": "ok"}


@app.get("/tasks")
def list_tasks():
    REQUESTS.labels("/tasks").inc()
    return tasks


@app.post("/tasks", status_code=201)
def create_task(task: TaskIn):
    if not task.title.strip():
        raise HTTPException(status_code=422, detail="title nie może być pusty")
    item = {"id": len(tasks) + 1, "title": task.title}
    tasks.append(item)
    TASKS_CREATED.inc()
    return item


@app.get("/metrics")
def metrics():
    return Response(generate_latest(), media_type=CONTENT_TYPE_LATEST)
